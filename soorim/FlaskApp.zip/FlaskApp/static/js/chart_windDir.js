document.addEventListener('DOMContentLoaded', () => {
  const regionConfigs = {
    '인천': { name: '인천', files: ['InCheon_05.csv'], color: 'blue' },
    '태안': { name: '태안', files: ['Taean_05.csv'], color: 'red' },
    '통영': { name: '통영', files: ['TongYeong_05.csv'], color: 'green' },
    '여수': { name: '여수', files: ['Yeosu_05.csv'], color: 'orange' },
    '울진': { name: '울진', files: ['Uljin_05.csv'], color: 'purple' },
  };

  const regionName = document.body.dataset.region;
  const regionConfig = regionConfigs[regionName];

  // ✅ 카테고리 버튼만 선택!
  
  document.querySelectorAll('.columns-grid .column-btn')
  const columnBtns = document.querySelectorAll('.columns-grid .column-btn');
  if (!columnBtns) return; 
  const chartPlaceholder = document.getElementById('chartPlaceholder');
  const chartTitle = document.getElementById('chartTitle');

  columnBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      // 그래프 버튼만 active 처리
      columnBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const btnText = btn.textContent.trim();

      if (btnText === '풍향') {
        chartTitle.textContent = `🌬️ ${regionConfig.name} 풍향장미도`;
        drawWindrose();
      } else {
        chartTitle.textContent = `📊 ${btnText} 변화 추이`;
        chartPlaceholder.innerHTML = '📈 그래프 영역<br><small>아직 구현되지 않았습니다</small>';
      }
    });
  });

  async function drawWindrose() {
    let windDirs = [];

    for (const file of regionConfig.files) {
      const response = await fetch(`/static/csv/${file}`);
      const csvText = await response.text();

      const lines = csvText.trim().split('\n');
      const headers = lines[0].split(',');
      const dirIdx = headers.indexOf('wind_dir');

      for (let i = 1; i < lines.length; i++) {
        const cols = lines[i].split(',');
        const dir = parseFloat(cols[dirIdx]);
        if (!isNaN(dir)) windDirs.push(dir);
      }
    }

    const bins = Array(16).fill(0);
    windDirs.forEach(dir => {
      const idx = Math.floor((dir % 360) / 22.5) % 16;
      bins[idx]++;
    });

    const directions = [
      'N', 'NNE', 'NE', 'ENE',
      'E', 'ESE', 'SE', 'SSE',
      'S', 'SSW', 'SW', 'WSW',
      'W', 'WNW', 'NW', 'NNW'
    ];

    const trace = {
      type: 'barpolar',
      r: bins,
      theta: directions,
      width: 360 / 16,
      marker: { color: regionConfig.color, opacity: 0.7 }
    };

    const layout = {
      title: `${regionConfig.name} 풍향장미도`,
      polar: {
        angularaxis: { direction: 'clockwise', rotation: 90 },
        radialaxis: { ticksuffix: '%', showline: false }
      }
    };

    Plotly.newPlot(chartPlaceholder, [trace], layout, { responsive: true });
  }
});
